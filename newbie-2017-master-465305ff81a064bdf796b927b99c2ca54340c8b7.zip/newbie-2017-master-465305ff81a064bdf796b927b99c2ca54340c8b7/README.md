# Chương trình đào tạo sinh viên thực tập 

# Nội dung bài tập
 * Tuần 1: Unpack các file trong thư mục `unpack` và viết cách làm, đẩy lên git
 * Tuần 2: 
      * phân tích mẫu RasTls.rar trong thư mục malware_tech/RasTls, password: infected 
	  * phân tích mẫu msdcsc.rar trong thư mục malware_tech/msdcsc, password: infected
	  * phân tích mẫu 7-Zip.zip trong thư mục malware_tech/ramnit, password: infected
 * Tuần 3: 
      * phân tích mẫu plugX.rar trong thư mục malware_tech/APT/, password: infected

	  
Lưu ý: khi phân tích malware, cần viết rõ các đặc điểm chính của malware : ghi file, ghi key, các domain kết nối tới. Báo cáo cần lưu ý các kĩ thuật mà malware sử dụng.